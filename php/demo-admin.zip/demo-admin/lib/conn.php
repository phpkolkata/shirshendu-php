<?php
$conn = mysqli_connect("localhost", "root", "", "kaustav_db");
if (!$conn) {
    die("connection error");
}
