<tr>
    <td width="25%" height="265" valign="top">
    <ul>
    <li><a href="category.php">Manage Category</a></li>
    <li><a href="product.php">Manage Product</a></li>
    <li><a href="">Manage Client</a></li>
    
    
    </td>
    <td width="75%" valign="top" align="center">