<?php
include "lib/admin_tpl/header.php";
include "lib/admin_tpl/nav.php";
//---------------------------------------
?>
body part
<?php
//------------------------------------------
include "lib/admin_tpl/footer.php";

?>
